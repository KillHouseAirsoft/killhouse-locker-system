# Web App (UI)

This directory is reserved for the front‑end application that will provide a user interface for interacting with the lockers.  The UI may be built using a modern framework such as React/Next.js, SvelteKit or Vue.  For the minimal viable product (MVP) you can also use a simple static site hosted on Vercel.

### Planned Features

- **Session start page** – a page that users reach after scanning a QR code on the locker; it will allow them to start a session and receive their 6‑digit PIN code.
- **Unlock terminal** – a touchscreen interface where customers enter their locker number and PIN to reopen the door as many times as needed.
- **Admin dashboard** – a control panel for staff to view locker status, manually open doors, end sessions or mark lockers out of order.
- **Real‑time updates** – integration with Supabase real‑time channels to update the UI when locker status changes.

The MVP is provided as a simple static page (`index.html`) that lists all lockers and provides buttons to start a session, open the locker or end the session.  The page uses the API endpoints under `/api/lockers` to perform these actions.

To test the static UI locally along with the API, you can serve the `web-app` directory with any static server and proxy API calls to the running Express server.  When deploying to Vercel, place the `index.html` in the root of your Vercel project or configure a Next.js front‑end.