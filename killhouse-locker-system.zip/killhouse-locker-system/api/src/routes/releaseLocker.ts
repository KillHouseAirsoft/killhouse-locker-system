import { Request, Response } from 'express';
import { supabase } from '../supabaseClient.js';

/**
 * POST /api/lockers/:lockerId/release
 * Ends an active locker session.  Requires the 6‑digit PIN code in the request
 * body { code: "123456" }.  If the code matches an active session, the session
 * status is updated to 'ended', the locker is set to available, and the
 * session’s ended_at timestamp is recorded.  If the session has already
 * expired or does not match the code, an error is returned.
 */
export async function releaseLocker(req: Request, res: Response) {
  const lockerId = req.params.lockerId;
  const { code } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'Missing PIN code' });
  }
  try {
    // Find active session for this locker and code
    const { data: session, error } = await supabase
      .from('locker_sessions')
      .select('*')
      .eq('locker_id', lockerId)
      .eq('pin_code', code)
      .eq('status', 'active')
      .single();
    if (error || !session) {
      return res.status(401).json({ error: 'Invalid code or no active session' });
    }
    // Mark session as ended
    const now = new Date();
    const { error: updateSessionError } = await supabase
      .from('locker_sessions')
      .update({ status: 'ended', ended_at: now.toISOString() })
      .eq('id', session.id);
    if (updateSessionError) {
      throw updateSessionError;
    }
    // Free the locker
    const { error: updateLockerError } = await supabase
      .from('lockers')
      .update({ status: 'available' })
      .eq('id', lockerId);
    if (updateLockerError) {
      throw updateLockerError;
    }
    return res.json({ success: true });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to end session' });
  }
}