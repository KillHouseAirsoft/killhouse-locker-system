import { Request, Response } from 'express';
import { supabase } from '../supabaseClient.js';

/**
 * GET /api/lockers/:lockerId
 * Retrieves the current status of a locker.  Returns whether the locker is
 * available or in_use along with metadata.  A separate call to
 * locker_sessions can reveal session details.
 */
export async function getLockerStatus(req: Request, res: Response) {
  const lockerId = req.params.lockerId;
  try {
    const { data, error } = await supabase
      .from('lockers')
      .select('*')
      .eq('id', lockerId)
      .single();
    if (error) {
      throw error;
    }
    if (!data) {
      return res.status(404).json({ error: 'Locker not found' });
    }
    return res.json(data);
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to retrieve locker status' });
  }
}