import { Request, Response } from 'express';
import { supabase } from '../supabaseClient.js';
// nanoid is no longer used for PIN generation.  We keep the import here
// in case future enhancements require unique IDs.

/**
 * POST /api/lockers/:lockerId/reserve
 * Starts a new locker session for a user.  Generates a six‑digit PIN code
 * and writes a session record to the database with an expiry 48 hours from
 * creation.  Returns the PIN code and expiry for later use.  The locker
 * status is set to `in_use` while a session is active.
 */
export async function reserveLocker(req: Request, res: Response) {
  const lockerId = req.params.lockerId;
  try {
    // Ensure locker exists and is available
    const { data: locker, error: lockerError } = await supabase
      .from('lockers')
      .select('status')
      .eq('id', lockerId)
      .single();
    if (lockerError || !locker) {
      return res.status(404).json({ error: 'Locker not found' });
    }
    if (locker.status !== 'available') {
      return res.status(400).json({ error: 'Locker is not available' });
    }
    // Generate a six‑digit numeric PIN.  Using Math.random ensures a pure
    // numeric code between 100000 and 999999.
    const pinNumber = Math.floor(100000 + Math.random() * 900000);
    const pin = pinNumber.toString();
    // Set session expiry to 48 hours from now
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
    // Insert new session
    const { error: insertError } = await supabase
      .from('locker_sessions')
      .insert({ locker_id: lockerId, pin_code: pin, expires_at: expiresAt.toISOString() });
    if (insertError) {
      throw insertError;
    }
    // Update locker status to in_use
    const { error: updateError } = await supabase
      .from('lockers')
      .update({ status: 'in_use' })
      .eq('id', lockerId);
    if (updateError) {
      throw updateError;
    }
    return res.json({ pin_code: pin, expires_at: expiresAt.toISOString() });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to reserve locker' });
  }
}