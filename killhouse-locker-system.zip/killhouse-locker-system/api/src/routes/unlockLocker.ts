import { Request, Response } from 'express';
import { supabase } from '../supabaseClient.js';

/**
 * POST /api/lockers/:lockerId/unlock
 * Unlocks a specific locker by verifying the provided 6‑digit PIN against an active
 * session.  If a session exists and is not expired, the locker remains in use and
 * the session’s last access time and count are updated.  If the session is expired,
 * the locker is freed and an error is returned.  A valid code is required in the body
 * as { code: "123456" }.
 */
export async function unlockLocker(req: Request, res: Response) {
  const lockerId = req.params.lockerId;
  const { code } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'Missing PIN code' });
  }
  try {
    // Retrieve active session for this locker and code
    const { data: session, error } = await supabase
      .from('locker_sessions')
      .select('*')
      .eq('locker_id', lockerId)
      .eq('pin_code', code)
      .eq('status', 'active')
      .single();
    if (error || !session) {
      return res.status(401).json({ error: 'Invalid code or no active session' });
    }
    // Check expiration
    const now = new Date();
    const expiresAt = new Date(session.expires_at);
    if (now > expiresAt) {
      // Mark session as expired and free the locker
      await supabase
        .from('locker_sessions')
        .update({ status: 'expired' })
        .eq('id', session.id);
      await supabase
        .from('lockers')
        .update({ status: 'available' })
        .eq('id', lockerId);
      return res.status(401).json({ error: 'Session expired' });
    }
    // Update session: increment access count and last_accessed_at
    const { error: updateSessionError } = await supabase
      .from('locker_sessions')
      .update({
        last_accessed_at: now.toISOString(),
        access_count: (session.access_count ?? 0) + 1
      })
      .eq('id', session.id);
    if (updateSessionError) {
      throw updateSessionError;
    }
    // Locker remains in use; we do not change its status here.
    // In a real implementation, call the locker controller API here
    return res.json({ success: true });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to unlock locker' });
  }
}