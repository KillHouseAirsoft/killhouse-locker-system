# System Architecture

The API locker system comprises multiple components that work together to provide a secure, scalable locker service.  This document outlines the high‑level architecture.

## Overview Diagram

```
Customer → Web App (Vercel) → API (Vercel) → Supabase → Raspberry Pi → Locker
```

1. **Web App** – Users interact with the lockers via a web application.  QR codes on the lockers lead to a reservation page.
2. **API** – The backend API receives requests from the web app to start or access locker sessions.  It validates six‑digit PIN codes, updates the database and calls the locker controller.
3. **Database (Supabase)** – Stores lockers and session records.  Each session contains a unique six‑digit code, timestamps and status.  Supabase provides a hosted PostgreSQL database with real‑time capabilities.
4. **Locker Controller (Raspberry Pi)** – A small server running inside the locker bank that listens for unlock commands and actuates relays and LEDs.
5. **Lockers** – Physical lockers connected to relays controlled by the Pi.

## Data Flow

1. **Start Session** – A user visits `/lockers/<id>` on the web app and starts a session.  The API generates a six‑digit PIN code, records an expiry (default 48 hours) and marks the locker as `in_use`.  The locker door is opened for the customer to place their belongings.
2. **Unlock** – When the customer wants to access their belongings, they enter the locker number and PIN code on the terminal.  The API verifies the code against the active session, updates the session’s last accessed time and opens the door via the Pi.  This can occur multiple times during a session.
3. **End Session / Expire** – When the customer is done, they can end the session by providing their PIN.  The session status is updated to `ended` and the locker is marked `available`.  If the session reaches its expiry or remains idle beyond a configured threshold, it automatically expires and the locker becomes available.  Staff can also end sessions through the admin interface.

## Security Considerations

- All API endpoints require HTTPS.  Vercel handles TLS termination.
- PIN codes are six‑digit numbers generated for each session.  They remain valid until the session is ended or expires (default 48 hours).  An optional idle timeout can expire the session earlier.
- The Pi is only accessible from the API via an internal network or through a secure Cloudflare tunnel.
- Sensitive credentials (Supabase keys, Pi tokens) should be stored in a secrets manager such as Bitwarden or Vercel’s environment variables.