# API Endpoints

This document lists the REST endpoints provided by the locker API.  All responses are JSON and should include appropriate HTTP status codes.

## `GET /api/lockers`

Return a list of all lockers.  Each locker record contains its id, name, current status, and other metadata.  Lockers are ordered by their numeric `id`.

### Request

No parameters are required.

### Response

- `200 OK` with a JSON array of locker objects, for example:

  ```json
  [
    {
      "id": 1,
      "name": "Locker 1",
      "status": "available",
      "created_at": "2026‑03‑09T10:00:00Z"
    },
    {
      "id": 2,
      "name": "Locker 2",
      "status": "in_use",
      "created_at": "2026‑03‑09T10:05:00Z"
    }
  ]
  ```

- `500 Internal Server Error` if an error occurs while retrieving the list.

## `GET /api/lockers/:lockerId`

Retrieve the current status of a single locker.

### Request

- `lockerId` (path parameter): The numeric ID of the locker.

### Response

- `200 OK` with a JSON body representing the locker, e.g.:

  ```json
  {
    "id": 1,
    "name": "Locker 1",
    "status": "available",
    "created_at": "2026‑03‑09T10:00:00Z"
  }
  ```
- `404 Not Found` if the locker does not exist.

## `POST /api/lockers/:lockerId/reserve`

Start a new locker session.  Generates a six‑digit PIN code and sets the locker status to `in_use`.  The PIN code remains valid for the duration of the session (default 48 hours) and can be used multiple times to open the locker until the session expires or is ended.

### Request

- `lockerId` (path parameter): ID of the locker to start a session on.

### Response

- `200 OK` with a JSON body containing the PIN code and expiry timestamp, e.g.:

  ```json
  { "pin_code": "482913", "expires_at": "2026‑03‑11T14:05:00Z" }
  ```

- `400 Bad Request` if the locker is not available.
- `404 Not Found` if the locker does not exist.

## `POST /api/lockers/:lockerId/unlock`

Open an in‑use locker using the 6‑digit PIN code for the active session.  This endpoint does not end the session and may be called multiple times until the session expires or is ended.

### Request

- `lockerId` (path parameter): ID of the locker to open.
- Body: `{ "code": "123456" }` – the six‑digit PIN code returned when the session was started.

### Response

- `200 OK` with `{ "success": true }` if the locker was successfully unlocked.
- `401 Unauthorized` if the code is invalid, does not match the active session, or the session has expired.
- `404 Not Found` if the locker does not exist.
- `500 Internal Server Error` for unexpected failures.

## `POST /api/lockers/:lockerId/release`

End an active locker session.  Requires the same 6‑digit PIN code used to unlock the locker.  If the code matches the active session, the locker is freed and the session is marked as ended.  Once ended, the PIN code can no longer be used.

### Request

- `lockerId` (path parameter): ID of the locker to end the session on.
- Body: `{ "code": "123456" }` – the six‑digit PIN code for the active session.

### Response

- `200 OK` with `{ "success": true }` if the session was ended and the locker is available again.
- `401 Unauthorized` if the code is invalid or there is no active session.
- `500 Internal Server Error` for unexpected failures.