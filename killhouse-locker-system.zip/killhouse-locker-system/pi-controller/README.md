# Raspberry Pi Locker Controller

This component runs on a Raspberry Pi inside the physical locker enclosure.  It listens for HTTP commands from the API server and actuates relays connected to individual lockers.  It also controls LED indicators (available, reserved, occupied).

## Hardware Requirements

- Raspberry Pi (any model with GPIO headers)
- Relay board (e.g. 8‑channel or 16‑channel) to drive the locker solenoids
- LED strips or individual LEDs for locker status indicators
- Network connectivity (Ethernet or Wi‑Fi)

## Python Script

The `controller.py` script uses Flask to expose a simple REST API on the Pi.  When it receives a request to unlock or reserve a locker, it activates the appropriate GPIO pins.

> **Note:** Running this script requires the `RPi.GPIO` library, which only works on a Pi.  For local testing, you can mock out the GPIO module.

### Setup

```bash
sudo apt update
sudo apt install python3-pip
pip3 install flask RPi.GPIO
```

### Running the controller

```bash
python3 controller.py
```

By default it listens on port 5000.  You can change the port by setting the `PORT` environment variable.