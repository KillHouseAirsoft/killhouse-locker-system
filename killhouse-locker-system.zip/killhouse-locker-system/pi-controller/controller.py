#!/usr/bin/env python3
"""
Flask server to control a bank of lockers via Raspberry Pi GPIO pins.

This script exposes two endpoints:

- `POST /lockers/<locker_id>/unlock` — energises the relay for a short time to unlock
  the specified locker.
- `POST /lockers/<locker_id>/reserve` — sets the LED indicator to show that the locker
  is reserved.

Environment variables:
- PORT: port to listen on (default 5000)

Note: The RPi.GPIO library will only work on a Raspberry Pi.  If you want to test on
your development machine, install the `gpiozero` or `RPi.GPIO` mock packages or wrap
the GPIO calls in try/except blocks as done below.
"""
import os
import time
from flask import Flask, request, jsonify

app = Flask(__name__)

try:
    import RPi.GPIO as GPIO
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
except ImportError:
    # Fallback for non‑Pi systems — provide dummy GPIO functions
    class DummyGPIO:
        BCM = BOARD = OUT = IN = None

        def setmode(self, *args, **kwargs):
            pass

        def setwarnings(self, flag):
            pass

        def setup(self, pin, mode):
            print(f"Mock: setup pin {pin} as {mode}")

        def output(self, pin, state):
            print(f"Mock: set pin {pin} to {state}")

        def cleanup(self):
            print("Mock: cleanup GPIO")

    GPIO = DummyGPIO()
    GPIO.setmode = lambda *args, **kwargs: None
    GPIO.setwarnings = lambda *args, **kwargs: None

# Map locker IDs to GPIO pins
LOCKER_PINS = {
    "1": 17,
    "2": 18,
    "3": 27,
    "4": 22,
    # Add more mappings as needed
}

# Setup GPIO pins for output
for pin in LOCKER_PINS.values():
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, False)


@app.route('/lockers/<locker_id>/unlock', methods=['POST'])
def unlock(locker_id):
    """Unlock the specified locker."""
    pin = LOCKER_PINS.get(str(locker_id))
    if pin is None:
        return jsonify({"error": "Unknown locker"}), 404
    # Pulse the relay
    GPIO.output(pin, True)
    time.sleep(0.5)  # hold for half a second
    GPIO.output(pin, False)
    return jsonify({"success": True})


@app.route('/lockers/<locker_id>/reserve', methods=['POST'])
def reserve(locker_id):
    """Reserve the specified locker by turning on a reservation indicator.
    For this demo, we simply print to stdout.  In a real system, you might
    light an LED or update a display.
    """
    print(f"Locker {locker_id} reserved")
    return jsonify({"success": True})


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)