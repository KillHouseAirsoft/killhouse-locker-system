-- Schema for Killhouse Locker System

-- Drop tables if they already exist (for idempotent migration)
drop table if exists reservations cascade;
drop table if exists locker_sessions cascade;
drop table if exists lockers cascade;

-- Create lockers table
create table lockers (
    id serial primary key,
    name text not null,
    status text not null default 'available',
    created_at timestamptz not null default now()
);

-- Create locker_sessions table
-- Each session represents a customer's use of a locker.  A six‑digit pin code
-- grants re‑entry for the duration of the session.  Sessions expire either
-- automatically after a configured period or when explicitly ended by the user or staff.
create table locker_sessions (
    id uuid primary key default gen_random_uuid(),
    locker_id integer not null references lockers(id) on delete cascade,
    pin_code text not null,
    status text not null default 'active', -- active | expired | ended
    started_at timestamptz not null default now(),
    last_accessed_at timestamptz not null default now(),
    expires_at timestamptz not null,
    access_count integer not null default 0,
    ended_at timestamptz
);

-- Add indexes for faster lookups
create index on locker_sessions (locker_id);
create index on locker_sessions (pin_code);