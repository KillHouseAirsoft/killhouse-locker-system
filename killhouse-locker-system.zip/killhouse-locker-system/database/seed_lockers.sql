-- Seed data for lockers
-- This script inserts 16 lockers into the lockers table.

insert into lockers (name, status)
values
  ('Locker 1', 'available'),
  ('Locker 2', 'available'),
  ('Locker 3', 'available'),
  ('Locker 4', 'available'),
  ('Locker 5', 'available'),
  ('Locker 6', 'available'),
  ('Locker 7', 'available'),
  ('Locker 8', 'available'),
  ('Locker 9', 'available'),
  ('Locker 10', 'available'),
  ('Locker 11', 'available'),
  ('Locker 12', 'available'),
  ('Locker 13', 'available'),
  ('Locker 14', 'available'),
  ('Locker 15', 'available'),
  ('Locker 16', 'available');