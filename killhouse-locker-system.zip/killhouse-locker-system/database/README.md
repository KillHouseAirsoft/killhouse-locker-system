# Database

The locker system uses [Supabase](https://supabase.com) as its backend database and authentication provider.  Supabase provides a hosted PostgreSQL instance with real‑time capabilities and an easy‑to‑use client library.

This directory contains the schema used for the lockers system.  You can apply it directly in the Supabase SQL editor or using the `psql` command‑line tool.

## Tables

### `lockers`

Represents each physical locker.

| Column   | Type     | Description                                       |
|---------|---------|---------------------------------------------------|
| id      | integer  | Primary key                                       |
| name    | text     | Human‑friendly name/label                         |
| status  | text     | Current state: `available` or `in_use`            |
| created_at | timestamp | Timestamp of creation                           |

### `locker_sessions`

Tracks active sessions for lockers.  Each session has a six‑digit PIN code and an expiry time.

| Column         | Type      | Description                                                     |
|---------------|----------|-----------------------------------------------------------------|
| id            | uuid      | Primary key                                                     |
| locker_id     | integer   | Foreign key to `lockers.id`                                     |
| pin_code      | text      | Six‑digit code used to open the locker                          |
| status        | text      | Session status: `active`, `expired` or `ended`                  |
| started_at    | timestamp | Timestamp when the session was created                          |
| last_accessed_at | timestamp | Timestamp of the most recent unlock event                   |
| expires_at    | timestamp | Timestamp when the session expires (default 48 hours)          |
| access_count  | integer   | Number of times the locker has been opened during the session   |
| ended_at      | timestamp | Timestamp when the session was ended (if applicable)            |

## Applying the schema

Copy the contents of `schema.sql` into the Supabase SQL editor and run it.  This will create the necessary tables and functions.